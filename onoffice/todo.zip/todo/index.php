<?php include "../../header.php" ?>
<?php include "../../controllers/todoClass.php";
$todoClass=new todoClass();
$todoDetailss=$todoClass->todoDetails($session_uid,$userDetails->company_id);
?>
<!--<head><meta http-equiv="refresh" content="5"></head>-->
<section class="vbox">
       <section class="scrollable padder">
	   <span style="float:right;"><a href="#"> <i class="fa fa-print">Print</i></a></span>
		   <header class="panel-heading font-bold">ToDo Management</header>
				   <link rel="stylesheet" href="css/reset.css">
  
	<link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
  <link rel="stylesheet" href="css/global.css">
               
				<div class="page-wrapper">

	<div class="main-container">
		<div class="row container">
				<div class="to-do-panel col-sm-4 col-lg-4 column">
					<h2>To Do</h2>
					<span class="lnr lnr-plus-circle button-toggle plus-sign"></span>
					<span style="float:right;"><a href="#"> <i class="fa fa-print"></i></a></span>

					<!-- the else condition is not working  -->
					<!-- <div class="alert alert-success">
							<strong>Success!</strong> Indicates a successful or positive action.
					</div> -->
					
					<form class="new-item-panel" action="#" method="post">
					
					<!--<input value="todo" type="text" id="input_todo" name="input_todo" class="input-title form-control">-->
							<input name="todo_item" placeholder="Add item" class="input-title form-control">
							<input type="text" name="todo_type" id="todo_type" placeholder="type todo" class="input-title form-control"/>
							<textarea placeholder="Add content" class="textarea-content form-control" rows="5"></textarea>
							<!-- <input class="input-img" type="file" name="pic" accept="image/*"> -->
							<button type="button" type="submit" class="btn btn-primary add-item float-right">Add</button>
					</form>

					

					<ul id="sortable1" class="connectedSortable">
					<?php
foreach($todoDetailss as $row):
	if($row['task'] == 'todo'){?>
						<li class="ui-state-default list-item">
							<!-- <img src="img/pic-1.jpeg" alt="projects" class="header-img"> -->
							<div class="item-container">
								<div class="row">
								<div class="col-sm-6">
									<div class="color-circle"></div>
								</div>

								<div class="col-sm-6">
								<div class="btn-group">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bars"></i>move to</a>
								<ul class="dropdown-menu pull-right">
								  <li><a href="../../controllers/onoffice_database/todo/todo_update.php?id=<?php echo $row['id']?>&type_todo=inprogress">move to inprogress</a></li>
								  <li><a href="../../controllers/onoffice_database/todo/todo_update.php?id=<?php echo $row['id']?>&type_todo=complete">move to complete</a></li>
								</ul>
							  </div>
						</div>
							</div>
								<h3><?php echo $row['item'];?></h3>
								<p><?php echo $row['content']; ?></p>
								<!-- <span class="ui-icon ui-icon-circle-minus"></span> -->
								
								<hr>
								<?php $carduserDetails=$userClass->userDetails($row['user_id']);?>
									
									<!--<a href="#" class="btn btn-sm btn-icon btn-info"><i class="fa fa-comment"></i></a>-->
									<small><?php echo $carduserDetails->first_name; ?></small>

									<a href="#"><span class="lnr lnr-users"style=" font-size: 1.5em;vertical-align: middle;float: right;transition: all 0.5s ease-in-out;&:hover{transform:rotate(-360deg);" data-toggle="modal" data-target="#todomodal"></span></a>
										<div id="todomodal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Assign User's</h4>
      </div>
      <div class="modal-body">
	 

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
		
		<a href="#"><span class="lnr lnr-file-add"style=" font-size: 1.5em;vertical-align: middle;float: right;transition: all 0.5s ease-in-out;      
	  &:hover{transform:rotate(-360deg);" data-toggle="modal" data-target="#myModal"></span></a>
		<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Upload Media</h4>
      </div>
      <div class="modal-body">
	  <?php
//$conn=new PDO('mysql:host=localhost; dbname=realestate', 'root', '') or die(mysql_error());
$db = getDB();
if(isset($_POST['submit'])!=""){
  $name=$_FILES['photo']['name'];
  $address_id=$_POST['id'];
  $size=$_FILES['photo']['size'];
  $type=$_FILES['photo']['type'];
  $temp=$_FILES['photo']['tmp_name'];
  //$caption1=$_POST['caption'];
  //$link=$_POST['link'];
  move_uploaded_file($temp,"upload/".$name);
$query=$db->query("insert into onoffice_todo_files(onoffice_todo_id,file_)values($address_id,'$name')");
if($query){
//header("location:index.php");
}
else{
die(mysql_error());
}
}
?>

	  <form enctype="multipart/form-data" action="" name="form" method="post">
     
<input type="hidden" name="id" value="<?php  echo  $row['id'];?>">
					<input type="file" name="photo" id="photo" required/></td>
        <br/>
					<input type="submit"  class="btn btn-s-md btn-info btn-rounded" name="submit" id="submit" value="Upload" />
         
                    
			</form>


			<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
			<thead>
				<tr>
					<th width="90%" align="center">Files</th>
					<th align="center">Action</th>	
				</tr>
			</thead>
			<?php
    	$query=$db->query("select * from onoffice_todo_files where onoffice_todo_id=".$row['id']." order by id desc");
    //echo("select * from onoffice_address_files where onoffice_address_id=".$_GET['id']." order by id desc");
    //$query=$conn->query("select * from onoffice_address_files order by id desc");
			while($row=$query->fetch()){
        $name=$row['file_'];
        $file_id=$row['id'];
			?>
			<tr>
			
				<td>
					&nbsp;<?php echo $name ;?>
				</td>
				<td>
					<!--<button class="alert-success"><a href="../../controllers/onoffice_database/onoffice_address/onoffice_address_files.php?file_id=<?php echo $file_id;?>">Delete</a></button>-->
          </td>
          <td>
          <button class="alert-success"><a href="onoffice_todo_files_download.php?filename=<?php echo $name;?>">Download</a></button>
				</td>
			</tr>
			<?php }?>
		</table>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
									<a href="../../controllers/onoffice_database/todo/todo_remove.php?id=<?php echo $row['id']?>"><span class="lnr lnr-trash"></span></a>
									<a href="../comment/index.php?id=<?php echo $row['id']?>" alt="comments"><span class="lnr lnr-bubble" style=" font-size: 1.5em;
									

									
      vertical-align: middle;
      float: right;
      transition: all 0.5s ease-in-out;      
      &:hover{transform:rotate(-360deg);"></span></a>
							</div>

						</li><?php }endforeach; ?>
					</ul>
				</div> 

				<div class="doing-panel col-sm-4 col-lg-4 column">
					<h2>In Progress</h2>
					<span class="lnr lnr-plus-circle button-toggle plus-sign"></span>
					<span style="float:right;"><a href="#"> <i class="fa fa-print"></i></a></span>

					<form class="new-item-panel">
							<input placeholder="Add item" class="input-title form-control">
							<input type="text" name="todo_type_inprogress" id="todo_type_inprogress" placeholder="type inprogress" class="input-title form-control"/>
							<textarea placeholder="Add content" class="textarea-content form-control" rows="5"></textarea>
							<button type="button" class="btn btn-primary add-item float-right">Add</button>
					</form>

					<ul id="sortable2" class="connectedSortable">
					<?php
					foreach($todoDetailss as $row):
					if($row['task'] == 'inprogress'){?>
											<li class="ui-state-default list-item">
												<!-- <img src="img/pic-1.jpeg" alt="projects" class="header-img"> -->
												<div class="item-container">
												<div class="row">
								<div class="col-sm-6">
									<div class="color-circle"></div>
								</div>

								<div class="col-sm-6">
								<div class="btn-group">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bars"></i>move to</a>
								<ul class="dropdown-menu pull-right">
								  <li><a href="../../controllers/onoffice_database/todo/todo_update.php?id=<?php echo $row['id']?>&type_todo=todo">move to todo</a></li>
								  <li><a href="../../controllers/onoffice_database/todo/todo_update.php?id=<?php echo $row['id']?>&type_todo=complete">move to complete</a></li>
								</ul>
							  </div>
						</div>
							</div>
													
													<h3><?php echo $row['item'];?></h3>
													<p><?php echo $row['content'];?></p>
										<hr>
										<?php $carduserDetails=$userClass->userDetails($row['user_id']);?>
									
											
											<small><?php echo $carduserDetails->first_name; ?></small>
											<a href="../../controllers/onoffice_database/todo/assign_users.php?id=<?php echo $row['id']?>"><span class="lnr lnr-users"style=" font-size: 1.5em;
									

									
      vertical-align: middle;
      float: right;
      transition: all 0.5s ease-in-out;      
	  &:hover{transform:rotate(-360deg);"></span></a>
		
		<a href="#"><span class="lnr lnr-file-add"style=" font-size: 1.5em;vertical-align: middle;float: right;transition: all 0.5s ease-in-out;      
	  &:hover{transform:rotate(-360deg);" data-toggle="modal" data-target="#myModal2"></span></a>
		<div id="myModal2" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Upload Media</h4>
      </div>
      <div class="modal-body">
	  <?php
//$conn=new PDO('mysql:host=localhost; dbname=realestate', 'root', '') or die(mysql_error());
$db = getDB();
if(isset($_POST['submit'])!=""){
  $name=$_FILES['photo']['name'];
  $address_id=$_POST['id'];
  $size=$_FILES['photo']['size'];
  $type=$_FILES['photo']['type'];
  $temp=$_FILES['photo']['tmp_name'];
  //$caption1=$_POST['caption'];
  //$link=$_POST['link'];
  move_uploaded_file($temp,"upload/".$name);
$query=$db->query("insert into onoffice_todo_files(onoffice_todo_id,file_)values($address_id,'$name')");
if($query){
//header("location:index.php");
}
else{
die(mysql_error());
}
}
?>

	  <form enctype="multipart/form-data" action="" name="form" method="post">
     
<input type="hidden" name="id" value="<?php  echo  $row['id'];?>">
					<input type="file" name="photo" id="photo" required/></td>
        <br/>
					<input type="submit"  class="btn btn-s-md btn-info btn-rounded" name="submit" id="submit" value="Upload" />
         
                    
			</form>


			<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
			<thead>
				<tr>
					<th width="90%" align="center">Files</th>
					<th align="center">Action</th>	
				</tr>
			</thead>
			<?php
    	$query=$db->query("select * from onoffice_todo_files where onoffice_todo_id=".$row['id']." order by id desc");
    //echo("select * from onoffice_address_files where onoffice_address_id=".$_GET['id']." order by id desc");
    //$query=$conn->query("select * from onoffice_address_files order by id desc");
			while($row=$query->fetch()){
        $name=$row['file_'];
        $file_id=$row['id'];
			?>
			<tr>
			
				<td>
					&nbsp;<?php echo $name ;?>
				</td>
				<td>
					<!--<button class="alert-success"><a href="../../controllers/onoffice_database/onoffice_address/onoffice_address_files.php?file_id=<?php echo $file_id;?>">Delete</a></button>-->
          </td>
          <td>
          <button class="alert-success"><a href="onoffice_todo_files_download.php?filename=<?php echo $name;?>">Download</a></button>
				</td>
			</tr>
			<?php }?>
		</table>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
											<a href="../../controllers/onoffice_database/todo/todo_remove.php?id=<?php echo $row['id']?>"><span class="lnr lnr-trash"></span></a>
											<a href="../comment/index.php?id=<?php echo $row['id']?>" alt="comments"><span class="lnr lnr-bubble" style=" font-size: 1.5em;
      vertical-align: middle;
      float: right;
      transition: all 0.5s ease-in-out;      
      &:hover{transform:rotate(-360deg);"></span></a>
											</div>
											
									
								</li><?php }endforeach; ?>
					</ul>
				</div>


				<div class="done-panel col-sm-4 col-lg-4 column">
					<h2>Complete</h2>
					<span class="lnr lnr-plus-circle button-toggle plus-sign"></span>
					<span style="float:right;"><a href="#"> <i class="fa fa-print"></i></a></span>
					
					<form class="new-item-panel">
							<input placeholder="Add item" class="input-title form-control">
							<input type="text" name="todo_type_complete" id="todo_type_complete" placeholder="type complete" class="input-title form-control"/>
							<textarea placeholder="Add content" class="textarea-content form-control" rows="5"></textarea>
							<button type="button" class="btn btn-primary add-item float-right">Add</button>
					</form>

					<ul id="sortable3" class="connectedSortable">
					<?php
					foreach($todoDetailss as $row):
						if($row['task'] == 'complete'){?>
											<li class="ui-state-default list-item">
												<!-- <img src="img/pic-1.jpeg" alt="projects" class="header-img"> -->
												<div class="item-container">
												<div class="row">
								<div class="col-sm-6">
									<div class="color-circle"></div>
								</div>

								<div class="col-sm-6">
								<div class="btn-group">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bars"></i>move to</a>
								<ul class="dropdown-menu pull-right">
								  <li><a href="../../controllers/onoffice_database/todo/todo_update.php?id=<?php echo $row['id']?>&type_todo=inprogress">move to inprogress</a></li>
								  <li><a href="../../controllers/onoffice_database/todo/todo_update.php?id=<?php echo $row['id']?>&type_todo=todo">move to todo</a></li>
								</ul>
							  </div>
						</div>
							</div>
													
													<h3><?php echo $row['item'];?></h3>
													<p><?php echo $row['content']; ?></p>
										<hr>
										<?php $carduserDetails=$userClass->userDetails($row['user_id']);?>
									
											
											<small><?php echo $carduserDetails->first_name; ?></small>
											<a href="../../controllers/onoffice_database/todo/assign_users.php?id=<?php echo $row['id']?>"><span class="lnr lnr-users"style=" font-size: 1.5em;
									

									
      vertical-align: middle;
      float: right;
      transition: all 0.5s ease-in-out;      
	  &:hover{transform:rotate(-360deg);"></span></a>
		
		<a href="#"><span class="lnr lnr-file-add"style=" font-size: 1.5em;vertical-align: middle;float: right;transition: all 0.5s ease-in-out;      
	  &:hover{transform:rotate(-360deg);" data-toggle="modal" data-target="#myModal3"></span></a>
		<div id="myModal3" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Upload Media</h4>
      </div>
      <div class="modal-body">
	  <?php
//$conn=new PDO('mysql:host=localhost; dbname=realestate', 'root', '') or die(mysql_error());
$db = getDB();
if(isset($_POST['submit'])!=""){
  $name=$_FILES['photo']['name'];
  $address_id=$_POST['id'];
  $size=$_FILES['photo']['size'];
  $type=$_FILES['photo']['type'];
  $temp=$_FILES['photo']['tmp_name'];
  //$caption1=$_POST['caption'];
  //$link=$_POST['link'];
  move_uploaded_file($temp,"upload/".$name);
$query=$db->query("insert into onoffice_todo_files(onoffice_todo_id,file_)values($address_id,'$name')");
if($query){
//header("location:index.php");
}
else{
die(mysql_error());
}
}
?>

	  <form enctype="multipart/form-data" action="" name="form" method="post">
     
<input type="hidden" name="id" value="<?php  echo  $row['id'];?>">
					<input type="file" name="photo" id="photo" required/></td>
        <br/>
					<input type="submit"  class="btn btn-s-md btn-info btn-rounded" name="submit" id="submit" value="Upload" />
         
                    
			</form>


			<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
			<thead>
				<tr>
					<th width="90%" align="center">Files</th>
					<th align="center">Action</th>	
				</tr>
			</thead>
			<?php
    	$query=$db->query("select * from onoffice_todo_files where onoffice_todo_id=".$row['id']." order by id desc");
    //echo("select * from onoffice_address_files where onoffice_address_id=".$_GET['id']." order by id desc");
    //$query=$conn->query("select * from onoffice_address_files order by id desc");
			while($row=$query->fetch()){
        $name=$row['file_'];
        $file_id=$row['id'];
			?>
			<tr>
			
				<td>
					&nbsp;<?php echo $name ;?>
				</td>
				<td>
					<!--<button class="alert-success"><a href="../../controllers/onoffice_database/onoffice_address/onoffice_address_files.php?file_id=<?php echo $file_id;?>">Delete</a></button>-->
          </td>
          <td>
          <button class="alert-success"><a href="onoffice_todo_files_download.php?filename=<?php echo $name;?>">Download</a></button>
				</td>
			</tr>
			<?php }?>
		</table>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
											<a href="../../controllers/onoffice_database/todo/todo_remove.php?id=<?php echo $row['id']?>"><span class="lnr lnr-trash"></span></a>		
											<a href="../comment/index.php?id=<?php echo $row['id']?>" alt="comments"><span class="lnr lnr-bubble" style=" font-size: 1.5em;
      vertical-align: middle;
      float: right;
      transition: all 0.5s ease-in-out;      
      &:hover{transform:rotate(-360deg);"></span></a>									
									</div>
									
								</li><?php } endforeach; ?>
					</ul>
				</div>

			</div>
		</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<!-- local javascript -->
<script src="js/javascript.js"></script>
                
        
   
      
      <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
    </section>
    <aside class="bg-light lter b-l aside-md hide" id="notes">
      <div class="wrapper">Notification</div>
    </aside>
  </section>



<?php include "../footer.php" ?>
 

  